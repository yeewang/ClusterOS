/* $OpenBSD: version.h,v 1.75 2015/08/21 03:45:26 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.1"

#define SSH_PORTABLE	"p2"
#define SSH_HPN         "-hpn14v10"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE SSH_HPN
